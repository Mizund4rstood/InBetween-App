
-- Recreate the SELECT policy with correct syntax (old one was already dropped)
CREATE POLICY "Users read own gratitude posts"
  ON public.gratitude_wall
  AS RESTRICTIVE
  FOR SELECT
  USING (auth.uid() = user_id);

-- Recreate the safe view as SECURITY DEFINER to allow public reads while masking user_id
DROP VIEW IF EXISTS public.gratitude_wall_safe;
CREATE VIEW public.gratitude_wall_safe
  WITH (security_invoker = false)
AS
SELECT
  id,
  message,
  created_at,
  CASE WHEN auth.uid() = user_id THEN user_id ELSE NULL END AS user_id
FROM public.gratitude_wall;

GRANT SELECT ON public.gratitude_wall_safe TO authenticated;
