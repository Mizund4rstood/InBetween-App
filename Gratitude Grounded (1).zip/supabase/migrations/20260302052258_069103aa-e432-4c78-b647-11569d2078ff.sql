
-- 1. Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- 2. Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.email));
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 3. Add user_id to data tables (nullable for migration)
ALTER TABLE public.compass_triggers ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.compass_choices ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE public.why_vault ADD COLUMN user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE;

-- 4. Drop all old permissive policies
DROP POLICY IF EXISTS "Anyone can read triggers" ON public.compass_triggers;
DROP POLICY IF EXISTS "Anyone can insert triggers" ON public.compass_triggers;
DROP POLICY IF EXISTS "Anyone can update triggers" ON public.compass_triggers;
DROP POLICY IF EXISTS "Anyone can delete triggers" ON public.compass_triggers;

DROP POLICY IF EXISTS "Anyone can read choices" ON public.compass_choices;
DROP POLICY IF EXISTS "Anyone can insert choices" ON public.compass_choices;
DROP POLICY IF EXISTS "Anyone can update choices" ON public.compass_choices;
DROP POLICY IF EXISTS "Anyone can delete choices" ON public.compass_choices;

DROP POLICY IF EXISTS "Anyone can read vault entries" ON public.why_vault;
DROP POLICY IF EXISTS "Anyone can insert vault entries" ON public.why_vault;
DROP POLICY IF EXISTS "Anyone can update vault entries" ON public.why_vault;
DROP POLICY IF EXISTS "Anyone can delete vault entries" ON public.why_vault;

DROP POLICY IF EXISTS "Anyone can read gratitude wall" ON public.gratitude_wall;
DROP POLICY IF EXISTS "Anyone can post to gratitude wall" ON public.gratitude_wall;

-- 5. Create auth-scoped policies for compass_triggers
CREATE POLICY "Users read own triggers"
  ON public.compass_triggers FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own triggers"
  ON public.compass_triggers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own triggers"
  ON public.compass_triggers FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own triggers"
  ON public.compass_triggers FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 6. Auth-scoped policies for compass_choices
CREATE POLICY "Users read own choices"
  ON public.compass_choices FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own choices"
  ON public.compass_choices FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own choices"
  ON public.compass_choices FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own choices"
  ON public.compass_choices FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 7. Auth-scoped policies for why_vault
CREATE POLICY "Users read own vault"
  ON public.why_vault FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own vault"
  ON public.why_vault FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own vault"
  ON public.why_vault FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own vault"
  ON public.why_vault FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 8. Gratitude wall: public read, authenticated insert only
CREATE POLICY "Public read gratitude wall"
  ON public.gratitude_wall FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users post to wall"
  ON public.gratitude_wall FOR INSERT
  TO authenticated
  WITH CHECK (true);
