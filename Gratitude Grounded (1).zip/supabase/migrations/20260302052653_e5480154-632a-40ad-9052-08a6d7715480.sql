-- Add ownership to gratitude posts for policy enforcement and anti-spam controls
ALTER TABLE public.gratitude_wall
ADD COLUMN IF NOT EXISTS user_id UUID;

CREATE INDEX IF NOT EXISTS idx_gratitude_wall_user_created_at
ON public.gratitude_wall (user_id, created_at DESC);

-- Replace permissive insert policy with user-bound insert policy
DROP POLICY IF EXISTS "Authenticated users post to wall" ON public.gratitude_wall;

CREATE POLICY "Authenticated users post to wall"
ON public.gratitude_wall
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Server-side validation + basic rate limit
CREATE OR REPLACE FUNCTION public.validate_gratitude_wall_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  recent_count INTEGER;
BEGIN
  IF NEW.user_id IS NULL OR NEW.user_id <> auth.uid() THEN
    RAISE EXCEPTION 'Invalid user context';
  END IF;

  NEW.message := btrim(NEW.message);

  IF NEW.message IS NULL OR char_length(NEW.message) < 1 OR char_length(NEW.message) > 280 THEN
    RAISE EXCEPTION 'Message must be between 1 and 280 characters';
  END IF;

  SELECT count(*) INTO recent_count
  FROM public.gratitude_wall
  WHERE user_id = NEW.user_id
    AND created_at > now() - interval '60 seconds';

  IF recent_count >= 3 THEN
    RAISE EXCEPTION 'Rate limit exceeded. Try again in a minute';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_gratitude_wall_insert ON public.gratitude_wall;
CREATE TRIGGER trg_validate_gratitude_wall_insert
BEFORE INSERT ON public.gratitude_wall
FOR EACH ROW
EXECUTE FUNCTION public.validate_gratitude_wall_insert();