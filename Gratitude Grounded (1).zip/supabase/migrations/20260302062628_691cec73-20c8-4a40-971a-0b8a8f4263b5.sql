
-- Remove the old broad SELECT policy that exposes user_id
DROP POLICY IF EXISTS "Authenticated read gratitude wall" ON public.gratitude_wall;
