
CREATE TABLE public.community_quiz_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  transition text NOT NULL,
  feelings text[] NOT NULL DEFAULT '{}',
  support text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

ALTER TABLE public.community_quiz_answers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own quiz answers"
  ON public.community_quiz_answers FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own quiz answers"
  ON public.community_quiz_answers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own quiz answers"
  ON public.community_quiz_answers FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
