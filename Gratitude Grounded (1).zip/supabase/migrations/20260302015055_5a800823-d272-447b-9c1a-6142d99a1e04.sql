ALTER TABLE public.compass_triggers ADD COLUMN urge text;
ALTER TABLE public.compass_choices ADD COLUMN chose_differently boolean DEFAULT false;