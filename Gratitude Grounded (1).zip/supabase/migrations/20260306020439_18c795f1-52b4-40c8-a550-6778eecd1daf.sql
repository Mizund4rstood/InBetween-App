
CREATE TABLE public.restlessness_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  tool_used TEXT NOT NULL,
  duration_seconds INTEGER DEFAULT NULL
);

ALTER TABLE public.restlessness_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own restlessness sessions"
  ON public.restlessness_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own restlessness sessions"
  ON public.restlessness_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own restlessness sessions"
  ON public.restlessness_sessions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
