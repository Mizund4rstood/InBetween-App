-- Create storage bucket for future self audio messages
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('future-self', 'future-self', false, 10485760, ARRAY['audio/webm', 'audio/mp4', 'audio/mpeg', 'audio/ogg', 'audio/wav']);

-- Create table to track future self messages
CREATE TABLE public.future_self_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL DEFAULT 'My Future Self Message',
  storage_path TEXT NOT NULL,
  duration_seconds INTEGER,
  context TEXT, -- e.g., 'urge', 'anxiety', 'general'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.future_self_messages ENABLE ROW LEVEL SECURITY;

-- RLS policies for future_self_messages
CREATE POLICY "Users read own messages" ON public.future_self_messages
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users insert own messages" ON public.future_self_messages
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own messages" ON public.future_self_messages
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own messages" ON public.future_self_messages
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Storage policies for future-self bucket
CREATE POLICY "Users can upload own audio"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'future-self' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can read own audio"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'future-self' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can delete own audio"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'future-self' AND
  (storage.foldername(name))[1] = auth.uid()::text
);