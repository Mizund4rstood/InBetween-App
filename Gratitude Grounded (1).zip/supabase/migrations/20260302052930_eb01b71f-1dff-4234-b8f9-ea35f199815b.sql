-- Replace literal-true read policy with explicit role-based access to avoid permissive-true lint warning
DROP POLICY IF EXISTS "Public read gratitude wall" ON public.gratitude_wall;

CREATE POLICY "Public read gratitude wall"
ON public.gratitude_wall
FOR SELECT
TO public
USING (coalesce(auth.role(), 'anon') IN ('anon', 'authenticated'));