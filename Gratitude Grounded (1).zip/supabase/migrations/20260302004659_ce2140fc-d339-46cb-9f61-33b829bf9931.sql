-- Create a public anonymous gratitude wall table
CREATE TABLE public.gratitude_wall (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.gratitude_wall ENABLE ROW LEVEL SECURITY;

-- Anyone can read wall posts
CREATE POLICY "Anyone can read gratitude wall"
  ON public.gratitude_wall FOR SELECT
  USING (true);

-- Anyone can insert (anonymous posts)
CREATE POLICY "Anyone can post to gratitude wall"
  ON public.gratitude_wall FOR INSERT
  WITH CHECK (true);

-- Enable realtime for live updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.gratitude_wall;