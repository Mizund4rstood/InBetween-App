-- Restrict gratitude wall reads to authenticated users only (app already requires auth)
DROP POLICY IF EXISTS "Public read gratitude wall" ON public.gratitude_wall;

CREATE POLICY "Authenticated read gratitude wall"
ON public.gratitude_wall
FOR SELECT
TO authenticated
USING (true);