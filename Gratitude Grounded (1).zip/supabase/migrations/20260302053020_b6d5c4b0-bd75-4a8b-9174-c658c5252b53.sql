-- Enforce user association for gratitude posts
ALTER TABLE public.gratitude_wall
ALTER COLUMN user_id SET NOT NULL;