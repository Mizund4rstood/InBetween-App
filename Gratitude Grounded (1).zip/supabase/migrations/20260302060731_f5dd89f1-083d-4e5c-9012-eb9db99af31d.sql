-- Force RLS on all sensitive tables (prevents bypass even by table owner)
ALTER TABLE public.compass_triggers FORCE ROW LEVEL SECURITY;
ALTER TABLE public.compass_choices FORCE ROW LEVEL SECURITY;
ALTER TABLE public.why_vault FORCE ROW LEVEL SECURITY;
ALTER TABLE public.gratitude_wall FORCE ROW LEVEL SECURITY;
ALTER TABLE public.profiles FORCE ROW LEVEL SECURITY;