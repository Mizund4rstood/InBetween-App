-- Enforce authenticated ownership on sensitive tables
ALTER TABLE public.compass_triggers
  ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE public.compass_choices
  ALTER COLUMN user_id SET NOT NULL;

ALTER TABLE public.why_vault
  ALTER COLUMN user_id SET NOT NULL;

-- Remove legacy device tracking identifiers now that auth-backed ownership is enforced
ALTER TABLE public.compass_triggers
  DROP COLUMN IF EXISTS device_id;

ALTER TABLE public.compass_choices
  DROP COLUMN IF EXISTS device_id;

ALTER TABLE public.why_vault
  DROP COLUMN IF EXISTS device_id;