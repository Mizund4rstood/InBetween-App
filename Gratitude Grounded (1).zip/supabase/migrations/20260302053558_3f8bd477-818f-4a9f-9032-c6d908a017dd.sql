-- Allow users to delete their own gratitude wall posts
CREATE POLICY "Users delete own gratitude posts"
ON public.gratitude_wall
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);