
-- Fix: Switch gratitude_wall_safe view to security_invoker=true
-- and add explicit SELECT policy for all authenticated users

-- 1. Set view to respect querying user's RLS
ALTER VIEW public.gratitude_wall_safe SET (security_invoker = true);

-- 2. Replace owner-only SELECT policy with authenticated read-all policy
DROP POLICY IF EXISTS "Users read own gratitude posts" ON public.gratitude_wall;
CREATE POLICY "Authenticated users read all posts"
  ON public.gratitude_wall FOR SELECT TO authenticated USING (true);
