
CREATE TABLE compass_triggers (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  device_id text NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  trigger_text text NOT NULL,
  emotion text,
  intensity int DEFAULT 5,
  context text,
  category text
);

CREATE TABLE compass_choices (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  device_id text NOT NULL,
  trigger_id uuid REFERENCES compass_triggers(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now() NOT NULL,
  choice_text text NOT NULL,
  aligned_with_values boolean DEFAULT false,
  pause_used boolean DEFAULT false,
  outcome_rating int DEFAULT 5
);

ALTER TABLE compass_triggers ENABLE ROW LEVEL SECURITY;
ALTER TABLE compass_choices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert triggers" ON compass_triggers FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can read triggers" ON compass_triggers FOR SELECT USING (true);
CREATE POLICY "Anyone can update triggers" ON compass_triggers FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete triggers" ON compass_triggers FOR DELETE USING (true);

CREATE POLICY "Anyone can insert choices" ON compass_choices FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can read choices" ON compass_choices FOR SELECT USING (true);
CREATE POLICY "Anyone can update choices" ON compass_choices FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete choices" ON compass_choices FOR DELETE USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE compass_triggers;
ALTER PUBLICATION supabase_realtime ADD TABLE compass_choices;
