
CREATE TABLE public.pause_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  feeling TEXT,
  duration_seconds INTEGER NOT NULL DEFAULT 60,
  completed BOOLEAN NOT NULL DEFAULT true,
  chose_deeper BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.pause_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own pause sessions"
  ON public.pause_sessions FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read own pause sessions"
  ON public.pause_sessions FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
