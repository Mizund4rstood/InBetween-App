-- Fix: set security_invoker = true so RLS of the querying user applies
ALTER VIEW public.gratitude_wall_safe SET (security_invoker = true);