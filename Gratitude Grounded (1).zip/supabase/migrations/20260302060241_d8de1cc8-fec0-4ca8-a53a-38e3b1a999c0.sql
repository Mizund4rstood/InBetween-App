-- Create a view that only exposes user_id to the post owner
CREATE OR REPLACE VIEW public.gratitude_wall_safe AS
SELECT
  id,
  message,
  created_at,
  CASE WHEN auth.uid() = user_id THEN user_id ELSE NULL END AS user_id
FROM public.gratitude_wall;

-- Grant access to the view
GRANT SELECT ON public.gratitude_wall_safe TO authenticated;