CREATE TABLE public.why_vault (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  device_id TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('why_change', 'who_become', 'never_back')),
  text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.why_vault ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read vault entries" ON public.why_vault FOR SELECT USING (true);
CREATE POLICY "Anyone can insert vault entries" ON public.why_vault FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update vault entries" ON public.why_vault FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete vault entries" ON public.why_vault FOR DELETE USING (true);