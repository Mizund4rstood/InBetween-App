import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Not authenticated" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch user data: triggers, choices
    const [triggersRes, choicesRes] = await Promise.all([
      supabase.from("compass_triggers").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(200),
      supabase.from("compass_choices").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(500),
    ]);

    const triggers = triggersRes.data || [];
    const choices = choicesRes.data || [];

    // Also parse local entries from request body (stored in localStorage)
    const body = await req.json().catch(() => ({}));
    const localEntries = body.entries || [];
    const groundingSessions = body.groundingSessions || [];

    // Minimum data threshold
    const totalDataPoints = triggers.length + choices.length + localEntries.length + groundingSessions.length;
    if (totalDataPoints < 10) {
      return new Response(JSON.stringify({ 
        patterns: [],
        message: "Keep checking in! Patterns emerge after more data points.",
        dataPoints: totalDataPoints,
        threshold: 10,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build analysis prompt
    const analysisData = {
      triggers: triggers.slice(0, 50).map(t => ({
        text: t.trigger_text,
        emotion: t.emotion,
        intensity: t.intensity,
        time: t.created_at,
        category: t.category,
        urge: t.urge,
      })),
      choices: choices.slice(0, 100).map(c => ({
        text: c.choice_text,
        aligned: c.aligned_with_values,
        paused: c.pause_used,
        choseDifferently: c.chose_differently,
        outcomeRating: c.outcome_rating,
        time: c.created_at,
      })),
      entries: localEntries.slice(0, 50).map((e: any) => ({
        mood: e.mood,
        stress: e.stress,
        regulation: e.regulationState,
        time: e.entryDatetime,
        note: e.note?.slice(0, 100),
      })),
      groundingSessions: groundingSessions.slice(0, 30).map((s: any) => ({
        type: s.type,
        duration: s.durationSec,
        preMood: s.preMood,
        postMood: s.postMood,
        time: s.sessionDatetime,
      })),
    };

    const systemPrompt = `You are a behavioral pattern analyst for a mental wellness app. Analyze the user's check-in data and identify meaningful patterns.

IMPORTANT RULES:
1. Be specific with times, days, and correlations
2. Focus on actionable insights the user can use
3. Be warm and non-judgmental - this is a mirror, not a critic
4. Identify 3-5 patterns maximum
5. Each pattern should have: type, description, confidence (low/medium/high), and an optional suggestion

Pattern types to look for:
- TIME_BASED: "Urges tend to spike around 8-9pm"
- DAY_BASED: "Mondays and Thursdays show higher stress"
- EMOTION_TRIGGER: "Anxiety often follows work-related triggers"
- REGULATION_SUCCESS: "Walking correlates with better emotion regulation"
- CHOICE_PATTERN: "You pause more often in the morning"
- MOOD_CYCLE: "Mood dips mid-week, improves on weekends"

Return ONLY valid JSON matching this schema:
{
  "patterns": [
    {
      "id": "unique-id",
      "type": "TIME_BASED|DAY_BASED|EMOTION_TRIGGER|REGULATION_SUCCESS|CHOICE_PATTERN|MOOD_CYCLE",
      "title": "Short title (5-8 words)",
      "description": "Detailed observation",
      "confidence": "low|medium|high",
      "suggestion": "Optional actionable advice",
      "dataPoints": number of data points supporting this
    }
  ],
  "summary": "One sentence overall observation about the user's patterns"
}`;

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "AI not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Analyze this behavioral data and find patterns:\n\n${JSON.stringify(analysisData, null, 2)}` },
        ],
        temperature: 0.3,
      }),
    });

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResponse.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits depleted." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      console.error("AI error:", aiResponse.status);
      return new Response(JSON.stringify({ error: "Pattern analysis failed" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiData = await aiResponse.json();
    const content = aiData.choices?.[0]?.message?.content || "{}";

    // Extract JSON from response (handle markdown code blocks)
    let jsonStr = content;
    const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) {
      jsonStr = jsonMatch[1];
    }

    let parsed;
    try {
      parsed = JSON.parse(jsonStr.trim());
    } catch {
      console.error("Failed to parse AI response:", content);
      parsed = { patterns: [], summary: "Unable to analyze patterns at this time." };
    }

    return new Response(JSON.stringify({
      ...parsed,
      dataPoints: totalDataPoints,
      analyzedAt: new Date().toISOString(),
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (e) {
    console.error("patterns error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
