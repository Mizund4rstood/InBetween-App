import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Get Spotify access token using Client Credentials flow
async function getSpotifyToken(): Promise<string> {
  const clientId = Deno.env.get("SPOTIFY_CLIENT_ID");
  const clientSecret = Deno.env.get("SPOTIFY_CLIENT_SECRET");
  if (!clientId || !clientSecret) throw new Error("Spotify credentials not configured");

  const resp = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
    },
    body: "grant_type=client_credentials",
  });

  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`Spotify token error: ${resp.status} ${text}`);
  }

  const data = await resp.json();
  return data.access_token;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { action, playlistUrl, artistUrl, trackUrl } = body;

    const spotifyToken = await getSpotifyToken();
    const BASE = "https://api.spotify.com/v1";
    const headers = { Authorization: `Bearer ${spotifyToken}` };
    let result: unknown;

    if (action === "playlist") {
      // Extract playlist ID from URL or use as-is
      const id = extractId(playlistUrl || "", "playlist");
      if (!id) throw new Error("Invalid playlist URL or ID");

      const res = await fetch(`${BASE}/playlists/${id}?fields=name,description,owner(display_name),tracks(total,items(track(name,artists(name),album(name,release_date),duration_ms,popularity)))`, { headers });
      if (!res.ok) throw new Error(`Spotify API error: ${res.status}`);
      const data = await res.json();

      result = {
        playlist: {
          name: data.name,
          description: data.description,
          owner: data.owner?.display_name,
          totalTracks: data.tracks?.total,
        },
        tracks: (data.tracks?.items || []).slice(0, 30).map((item: any) => ({
          name: item.track?.name,
          artists: item.track?.artists?.map((a: any) => a.name).join(", "),
          album: item.track?.album?.name,
          releaseDate: item.track?.album?.release_date,
          popularity: item.track?.popularity,
        })),
      };

    } else if (action === "artist") {
      const id = extractId(artistUrl || "", "artist");
      if (!id) throw new Error("Invalid artist URL or ID");

      // Fetch artist info and top tracks in parallel
      const [artistRes, topTracksRes] = await Promise.all([
        fetch(`${BASE}/artists/${id}`, { headers }),
        fetch(`${BASE}/artists/${id}/top-tracks?market=US`, { headers }),
      ]);

      if (!artistRes.ok) throw new Error(`Spotify API error: ${artistRes.status}`);
      const artist = await artistRes.json();
      const topTracks = topTracksRes.ok ? await topTracksRes.json() : { tracks: [] };

      result = {
        artist: {
          name: artist.name,
          genres: artist.genres?.slice(0, 5),
          followers: artist.followers?.total,
          popularity: artist.popularity,
        },
        topTracks: (topTracks.tracks || []).slice(0, 10).map((t: any) => ({
          name: t.name,
          album: t.album?.name,
          popularity: t.popularity,
        })),
      };

    } else if (action === "track") {
      const id = extractId(trackUrl || "", "track");
      if (!id) throw new Error("Invalid track URL or ID");

      // Fetch track info and audio features
      const [trackRes, featuresRes] = await Promise.all([
        fetch(`${BASE}/tracks/${id}`, { headers }),
        fetch(`${BASE}/audio-features/${id}`, { headers }),
      ]);

      if (!trackRes.ok) throw new Error(`Spotify API error: ${trackRes.status}`);
      const track = await trackRes.json();
      const features = featuresRes.ok ? await featuresRes.json() : null;

      result = {
        track: {
          name: track.name,
          artists: track.artists?.map((a: any) => a.name).join(", "),
          album: track.album?.name,
          releaseDate: track.album?.release_date,
          popularity: track.popularity,
          durationMs: track.duration_ms,
        },
        audioFeatures: features ? {
          energy: features.energy,
          valence: features.valence,
          danceability: features.danceability,
          tempo: features.tempo,
          acousticness: features.acousticness,
          instrumentalness: features.instrumentalness,
        } : null,
      };

    } else {
      return new Response(
        JSON.stringify({ error: "Invalid action. Use: playlist, artist, track" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (e) {
    console.error("spotify-data error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function extractId(input: string, type: string): string | null {
  const trimmed = input.trim();
  // Direct ID (22 char alphanumeric)
  if (/^[a-zA-Z0-9]{22}$/.test(trimmed)) return trimmed;
  // URL pattern: open.spotify.com/{type}/{id}
  const match = trimmed.match(new RegExp(`spotify\\.com\\/${type}\\/([a-zA-Z0-9]+)`));
  return match?.[1] || null;
}
