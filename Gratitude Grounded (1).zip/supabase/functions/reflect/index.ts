import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const allowedOrigins = [
  "https://gentle-grounding-joy.lovable.app",
  "https://id-preview--b5285541-4c85-44d9-aaa6-259929d7ba8b.lovable.app",
  "http://localhost:5173",
  "http://localhost:8080",
];

function getCorsHeaders(req: Request) {
  const origin = req.headers.get("origin") || "";
  return {
    "Access-Control-Allow-Origin": allowedOrigins.includes(origin) ? origin : allowedOrigins[0],
    "Access-Control-Allow-Headers":
      "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  };
}

// ── Zod schemas ──

const MAX_TEXT = 2000;
const safeText = z.string().max(MAX_TEXT).transform(s => s.substring(0, MAX_TEXT));

const entrySchema = z.object({
  id: z.string().max(100).optional(),
  date: z.string().max(50).optional(),
  created_at: z.string().max(50).optional(),
  mood: z.union([z.string().max(50), z.number()]).optional(),
  stress: z.union([z.string().max(50), z.number()]).optional(),
  energy: z.union([z.string().max(50), z.number()]).optional(),
  regulation: z.string().max(100).optional(),
  note: safeText.optional(),
  notes: safeText.optional(),
  trigger: safeText.optional(),
  trigger_text: safeText.optional(),
  intensity: z.number().min(0).max(10).optional(),
  emotion: z.string().max(100).optional(),
  category: z.string().max(100).optional(),
  urge: safeText.optional(),
  context: safeText.optional(),
  delay_seconds: z.number().min(0).max(86400).optional(),
  acted_on: z.boolean().optional(),
  replacement: safeText.optional(),
  outcome_rating: z.number().min(0).max(10).optional(),
  choice_text: safeText.optional(),
  aligned_with_values: z.boolean().optional(),
  pause_used: z.boolean().optional(),
  chose_differently: z.boolean().optional(),
}).strict().catch({});

const groundingSessionSchema = z.object({
  id: z.string().max(100).optional(),
  date: z.string().max(50).optional(),
  created_at: z.string().max(50).optional(),
  type: z.string().max(50).optional(),
  duration: z.number().min(0).max(7200).optional(),
  duration_sec: z.number().min(0).max(7200).optional(),
  mood_before: z.union([z.string().max(50), z.number()]).optional(),
  mood_after: z.union([z.string().max(50), z.number()]).optional(),
  technique: z.string().max(100).optional(),
  completed: z.boolean().optional(),
}).strict().catch({});

const messageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: safeText,
}).transform(m => ({
  role: m.role === "assistant" ? "assistant" as const : "user" as const,
  content: m.content,
}));

const VALID_TYPES = [
  "weekly_reflection", "predictive_nudge", "adaptive_grounding",
  "identity_shift", "rewire_reflection", "chat",
] as const;

const youtubeDataSchema = z.object({
  channelTitle: z.string().max(200).optional(),
  recentVideos: z.array(z.object({
    title: safeText,
    description: safeText.optional(),
    publishedAt: z.string().max(50).optional(),
  }).strict().catch({})).max(20).optional().default([]),
  playlistTitle: z.string().max(200).optional(),
  playlistVideos: z.array(z.object({
    title: safeText,
    description: safeText.optional(),
    channelTitle: z.string().max(200).optional(),
  }).strict().catch({})).max(20).optional().default([]),
}).strict().catch({});

const spotifyDataSchema = z.object({
  playlistName: z.string().max(200).optional(),
  tracks: z.array(z.object({
    name: safeText,
    artists: safeText,
  }).strict().catch({})).max(30).optional().default([]),
  artistName: z.string().max(200).optional(),
  genres: z.array(z.string().max(100)).max(10).optional().default([]),
  topTracks: z.array(z.object({
    name: safeText,
  }).strict().catch({})).max(15).optional().default([]),
}).strict().catch({});

const requestSchema = z.object({
  type: z.enum(VALID_TYPES),
  entries: z.array(entrySchema).max(100).optional().default([]),
  streak: z.number().int().min(0).max(10000).optional().default(0),
  regulationHistory: z.array(z.string().max(200)).max(200).optional().default([]),
  groundingSessions: z.array(groundingSessionSchema).max(100).optional().default([]),
  messages: z.array(messageSchema).max(20).optional().default([]),
  youtubeData: youtubeDataSchema.optional(),
  spotifyData: spotifyDataSchema.optional(),
});

// ── System prompt ──

const SYSTEM_VOICE = `You are the AI inside InBetween — a self-awareness and regulation training tool for people who work hard. Truck drivers. Mechanics. Retail workers. Construction. Night shift.

YOUR VOICE:
You talk like a friend at a job site. Not a therapist. Not a life coach. Not a podcast bro. A real person who's been through some shit and came out the other side paying attention.

RULES:
- Short sentences. Punch hard. Get out.
- Never say "I hear you" or "That must be hard" or "It's okay to feel." That's therapy talk. Cut it.
- Say "wired" not "activated." "Checked out" not "dissociated." "Staying level" not "emotional regulation." "Your wiring" not "your nervous system."
- No clinical words. Ever. No "trauma," "anxiety," "depression," "cognitive distortion," "coping mechanism."
- Don't pathologize. Being stressed after a 10-hour shift is Tuesday, not a diagnosis.
- Frame everything as reps. "You caught it this time." "That's a rep." "You're stacking days."
- Identity over behavior: "You're someone who pauses now." Not "You should try to pause more."
- Never shame gaps. Showing back up IS the point. Period.
- Reference their actual data. Their words. Their numbers. Not generic rah-rah.
- Max 2-3 sentences unless they ask for more. These people are on break. Respect their time.
- Sound like you've worked a double and still showed up. That's the energy.
- Swear sparingly but naturally. "That's a solid week" hits harder than "Great job!"
- No emojis in responses. Words only.`;

// ── Prompt builders per type ──

function buildPrompt(input: z.infer<typeof requestSchema>) {
  const { type, entries, streak, regulationHistory, groundingSessions, messages, youtubeData, spotifyData } = input;

  // Build YouTube context block if available
  let ytContext = "";
  const hasChannelVideos = youtubeData?.recentVideos?.length;
  const hasPlaylistVideos = youtubeData?.playlistVideos?.length;
  if (hasChannelVideos || hasPlaylistVideos) {
    let ytParts: string[] = [];
    if (hasChannelVideos) {
      const titles = youtubeData.recentVideos.map((v: any) => v.title).filter(Boolean).join(", ");
      ytParts.push(`Channel "${youtubeData.channelTitle || 'unknown'}" recent videos: ${titles}`);
    }
    if (hasPlaylistVideos) {
      const plTitles = youtubeData.playlistVideos.map((v: any) => v.title).filter(Boolean).join(", ");
      ytParts.push(`Curated playlist "${youtubeData.playlistTitle || 'unknown'}" contains: ${plTitles}`);
    }
    ytContext = `\n\nYOUTUBE CONTEXT: ${ytParts.join(". ")}. Use this to read what they're drawn to — themes, interests, what they consume when they're decompressing or seeking something. A curated playlist is especially telling — it's intentional. Don't just list videos. Interpret what it says about where their head is at.`;
  }

  // Build Spotify context block if available
  let spContext = "";
  if (spotifyData?.tracks?.length || spotifyData?.artistName) {
    let spParts: string[] = [];
    if (spotifyData.tracks?.length) {
      const trackList = spotifyData.tracks.slice(0, 15).map((t: any) => `${t.name} by ${t.artists}`).join(", ");
      spParts.push(`Playlist "${spotifyData.playlistName || 'unknown'}": ${trackList}`);
    }
    if (spotifyData.artistName) {
      const genres = spotifyData.genres?.join(", ") || "unknown genres";
      const tops = spotifyData.topTracks?.slice(0, 5).map((t: any) => t.name).join(", ") || "";
      spParts.push(`Favorite artist: ${spotifyData.artistName} (genres: ${genres})${tops ? `. Top tracks: ${tops}` : ""}`);
    }
    spContext = `\n\nSPOTIFY CONTEXT: ${spParts.join(". ")}. Music taste reveals emotional state. Read the genres, energy, themes. Are they listening to heavy stuff? Mellow? Angry? Nostalgic? What does this say about where they're at right now? Don't list songs — interpret the vibe. If artist genres are provided, use them to read deeper patterns.`;
  }

  let systemPrompt = SYSTEM_VOICE;
  let userMessages: { role: string; content: string }[] = [];

  if (type === "weekly_reflection") {
    systemPrompt += `\n\nTASK: Write a weekly read based on the user's check-ins from the past 7 days.
Structure:
1. One line acknowledging the week — straight, not warm-and-fuzzy
2. 2-3 patterns you spotted (use their actual words/data)
3. One line on their wiring trend (are they more level? more wired? checked out more?)
4. One identity line: "You're someone who..." or "You're getting better at..."
${(hasChannelVideos || hasPlaylistVideos) ? '5. If YouTube data is provided, one line reading what their content consumption says about where they are right now. Be specific — name a video theme. If playlist data is present, note what the curation says about their intentional choices.' : ''}
${spotifyData?.tracks?.length ? '6. If Spotify data is provided, one line reading the emotional vibe of their playlist — what the music says about their state.' : ''}
Keep it under 150 words. Be blunt. Be specific.` + ytContext + spContext;
    userMessages = [{
      role: "user",
      content: `My check-ins this week:\n${JSON.stringify(entries, null, 2)}\n\nStreak: ${streak} days\nWiring states this week: ${JSON.stringify(regulationHistory)}`
    }];

  } else if (type === "predictive_nudge") {
    systemPrompt += `\n\nTASK: Look at the user's history and predict if tomorrow might be rough. Find day-of-week patterns, stress spikes, wiring trends.
If no pattern is clear, return: {"nudge": null}
If you see something, return JSON:
{"nudge": {"message": "...", "toolkit": ["breathing", "grounding", "vault"], "confidence": "low|medium|high"}}
The message should be a heads-up, not a warning. Like a coworker saying "Hey, Wednesdays have been hitting you hard. Might want to check in early."
Return ONLY valid JSON.`;
    userMessages = [{
      role: "user",
      content: `My recent check-ins (last 30 days):\n${JSON.stringify(entries, null, 2)}\nToday is ${new Date().toLocaleDateString('en-US', { weekday: 'long' })}.`
    }];

  } else if (type === "adaptive_grounding") {
    systemPrompt += `\n\nTASK: Build a personalized reset plan based on what's worked for them.
Look at: which exercises they've done, mood changes before/after, time of day, wiring states.
Return JSON:
{"plan": {"title": "...", "description": "...", "exercises": [{"type": "breathing|54321|combined", "duration_sec": number, "best_time": "morning|afternoon|evening", "reason": "..."}], "weekly_goal": "..."}}
Keep it practical. 2-3 exercises max. Reference their data. Make it feel like a plan, not a prescription.
Return ONLY valid JSON.`;
    userMessages = [{
      role: "user",
      content: `My grounding sessions:\n${JSON.stringify(groundingSessions, null, 2)}\nMy recent check-ins:\n${JSON.stringify(entries.slice(0, 20), null, 2)}\nWiring patterns: ${JSON.stringify(regulationHistory)}`
    }];

  } else if (type === "identity_shift") {
    systemPrompt += `\n\nTASK: Show the user who they're becoming. Compare early entries to recent ones. Look for:
- Are they noticing more? Using different words?
- Are they more level? Less reactive?
- What's changed in what they pay attention to?
- Are they more consistent?
${(hasChannelVideos || hasPlaylistVideos) ? '- What does their YouTube consumption (and curated playlists) say about their evolving interests or mindset?' : ''}
${spotifyData?.tracks?.length ? '- What does their music taste say about their emotional evolution?' : ''}
Write one blunt observation about the shift you see. Then one identity line.
Under 50 words. No fluff. Hit hard with truth.` + ytContext + spContext;
    userMessages = [{
      role: "user",
      content: `My earliest check-ins:\n${JSON.stringify(entries.slice(-5), null, 2)}\n\nMy most recent:\n${JSON.stringify(entries.slice(0, 5), null, 2)}\n\nStreak: ${streak} days\nTotal check-ins: ${entries.length}`
    }];

  } else if (type === "rewire_reflection") {
    systemPrompt += `\n\nTASK: Weekly rewire read. The user is in a 12-week behavior change program tracking urges, delay times, and replacement behaviors.

Look at their urge data and tell them what you see. Structure:
1. One blunt line about the week — no cheerleading, just the read
2. Patterns: What urge type hits hardest? When? What intensity trend?
3. Delay growth: Are they building pause? Compare recent delay to earlier
4. Resistance rate: How often are they riding it out vs acting on it?
5. If they used replacements, which ones are sticking?
6. One identity line: "You're becoming someone who..." based on the data
${(hasChannelVideos || hasPlaylistVideos) ? '7. If YouTube data available — one line on whether their content consumption (including curated playlists) aligns with or contradicts their rewire goals.' : ''}
${spotifyData?.tracks?.length ? '8. If Spotify data available — one line on what the music vibe says about their emotional state during rewire.' : ''}

Rules:
- Reference their actual numbers. "Your delay went from 0 to 45 seconds" not "You're improving"
- If they slipped, don't sugarcoat. But don't shame. "You acted on 3 out of 5. But you logged all 5. That's awareness."
- If delay is growing, that's the big win. Say it plain.
- Under 120 words. These people are busy.
- Phase context matters: Phase 1 is just noticing. Phase 2 is building delay. Phase 3 is replacements. Phase 4 is identity.` + ytContext + spContext;
    userMessages = [{
      role: "user",
      content: `My rewire data:
Phase: ${entries.length ? 'provided below' : 'unknown'}
Week: ${streak || 'unknown'}
Urges logged: ${JSON.stringify(entries, null, 2)}
Metrics: ${JSON.stringify(regulationHistory)}
Active urge types: ${JSON.stringify(groundingSessions)}`
    }];

  } else if (type === "chat") {
    systemPrompt += `\n\nTASK: The user is asking about their patterns. You have their data. Be direct, specific, and useful.
Don't repeat their data back to them — interpret it. Tell them what you see. Ask one sharp follow-up question if it helps.
Keep responses under 80 words.` + ytContext + spContext;
    const contextMsg = {
      role: "user",
      content: `[CONTEXT - my recent check-ins, don't repeat these]:\n${JSON.stringify(entries.slice(0, 10), null, 2)}\nStreak: ${streak} days`
    };
    const validMessages = messages.filter(m => m.content.length > 0);
    userMessages = [contextMsg, ...validMessages];
  }

  return { systemPrompt, userMessages, isChat: type === "chat" };
}

// ── Handler ──

serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Parse & validate with zod
    let rawBody: unknown;
    try {
      rawBody = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const parseResult = requestSchema.safeParse(rawBody);
    if (!parseResult.success) {
      const issues = parseResult.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join('; ');
      return new Response(JSON.stringify({ error: `Validation failed: ${issues}` }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const input = parseResult.data;
    const { systemPrompt, userMessages, isChat } = buildPrompt(input);

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const aiMessages = [
      { role: "system", content: systemPrompt },
      ...userMessages,
    ];

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: aiMessages,
        ...(isChat ? { stream: true } : {}),
      }),
    });

    if (!response.ok) {
      const status = response.status;
      if (status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit reached. Try again in a sec." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (status === 402) {
        return new Response(JSON.stringify({ error: "AI usage limit hit." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", status, t);
      throw new Error(`AI gateway error: ${status}`);
    }

    if (isChat) {
      return new Response(response.body, {
        headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";

    return new Response(JSON.stringify({ result: content }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (e) {
    console.error("reflect error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
