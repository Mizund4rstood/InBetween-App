import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { action, channelId, query, maxResults = 10 } = body;

    const YOUTUBE_API_KEY = Deno.env.get("YOUTUBE_API_KEY");
    if (!YOUTUBE_API_KEY) {
      throw new Error("YOUTUBE_API_KEY not configured");
    }

    const BASE = "https://www.googleapis.com/youtube/v3";
    let result: unknown;

    if (action === "search") {
      // Search for videos by query
      const params = new URLSearchParams({
        part: "snippet",
        q: query || "",
        type: "video",
        maxResults: String(Math.min(maxResults, 25)),
        key: YOUTUBE_API_KEY,
      });
      const res = await fetch(`${BASE}/search?${params}`);
      result = await res.json();

    } else if (action === "channel") {
      // Get channel info by ID or username
      const params = new URLSearchParams({
        part: "snippet,statistics,contentDetails",
        key: YOUTUBE_API_KEY,
        ...(channelId?.startsWith("UC")
          ? { id: channelId }
          : { forHandle: channelId || "" }),
      });
      const res = await fetch(`${BASE}/channels?${params}`);
      const data = await res.json();

      if (data.items?.length) {
        const channel = data.items[0];
        const uploadsPlaylistId =
          channel.contentDetails?.relatedPlaylists?.uploads;

        // Fetch recent uploads
        let recentVideos: unknown[] = [];
        if (uploadsPlaylistId) {
          const uploadsParams = new URLSearchParams({
            part: "snippet",
            playlistId: uploadsPlaylistId,
            maxResults: String(Math.min(maxResults, 25)),
            key: YOUTUBE_API_KEY,
          });
          const uploadsRes = await fetch(`${BASE}/playlistItems?${uploadsParams}`);
          const uploadsData = await uploadsRes.json();
          recentVideos = uploadsData.items || [];
        }

        result = {
          channel: {
            id: channel.id,
            title: channel.snippet?.title,
            description: channel.snippet?.description,
            subscriberCount: channel.statistics?.subscriberCount,
            videoCount: channel.statistics?.videoCount,
            viewCount: channel.statistics?.viewCount,
          },
          recentVideos: recentVideos.map((v: any) => ({
            title: v.snippet?.title,
            description: v.snippet?.description,
            publishedAt: v.snippet?.publishedAt,
            thumbnail: v.snippet?.thumbnails?.medium?.url,
          })),
        };
      } else {
        result = { error: "Channel not found" };
      }

    } else if (action === "playlists") {
      // Get public playlists for a channel
      const params = new URLSearchParams({
        part: "snippet,contentDetails",
        channelId: channelId || "",
        maxResults: String(Math.min(maxResults, 25)),
        key: YOUTUBE_API_KEY,
      });
      const res = await fetch(`${BASE}/playlists?${params}`);
      const data = await res.json();
      result = {
        playlists: (data.items || []).map((p: any) => ({
          id: p.id,
          title: p.snippet?.title,
          description: p.snippet?.description,
          videoCount: p.contentDetails?.itemCount,
          thumbnail: p.snippet?.thumbnails?.medium?.url,
        })),
      };

    } else if (action === "playlist") {
      // Get a specific playlist by ID with its items
      const playlistId = body.playlistId || channelId || "";
      const plParams = new URLSearchParams({
        part: "snippet,contentDetails",
        id: playlistId,
        key: YOUTUBE_API_KEY,
      });
      const plRes = await fetch(`${BASE}/playlists?${plParams}`);
      const plData = await plRes.json();

      if (plData.items?.length) {
        const pl = plData.items[0];
        // Fetch playlist items
        const itemsParams = new URLSearchParams({
          part: "snippet",
          playlistId,
          maxResults: String(Math.min(maxResults, 25)),
          key: YOUTUBE_API_KEY,
        });
        const itemsRes = await fetch(`${BASE}/playlistItems?${itemsParams}`);
        const itemsData = await itemsRes.json();

        result = {
          playlist: {
            id: pl.id,
            title: pl.snippet?.title,
            description: pl.snippet?.description,
            channelTitle: pl.snippet?.channelTitle,
            videoCount: pl.contentDetails?.itemCount,
            thumbnail: pl.snippet?.thumbnails?.medium?.url,
          },
          videos: (itemsData.items || []).map((v: any) => ({
            title: v.snippet?.title,
            description: v.snippet?.description,
            publishedAt: v.snippet?.publishedAt,
            thumbnail: v.snippet?.thumbnails?.medium?.url,
            channelTitle: v.snippet?.channelTitle,
          })),
        };
      } else {
        result = { error: "Playlist not found" };
      }

    } else if (action === "video_details") {
      // Get details for specific video IDs
      const videoIds = body.videoIds || [];
      if (videoIds.length > 0) {
        const params = new URLSearchParams({
          part: "snippet,statistics,contentDetails",
          id: videoIds.slice(0, 50).join(","),
          key: YOUTUBE_API_KEY,
        });
        const res = await fetch(`${BASE}/videos?${params}`);
        const data = await res.json();
        result = {
          videos: (data.items || []).map((v: any) => ({
            id: v.id,
            title: v.snippet?.title,
            description: v.snippet?.description,
            publishedAt: v.snippet?.publishedAt,
            channelTitle: v.snippet?.channelTitle,
            tags: v.snippet?.tags?.slice(0, 10),
            categoryId: v.snippet?.categoryId,
            viewCount: v.statistics?.viewCount,
            likeCount: v.statistics?.likeCount,
            duration: v.contentDetails?.duration,
          })),
        };
      } else {
        result = { videos: [] };
      }

    } else {
      return new Response(
        JSON.stringify({ error: "Invalid action. Use: search, channel, playlist, playlists, video_details" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (e) {
    console.error("youtube-data error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
