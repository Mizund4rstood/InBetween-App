import { useMemo } from 'react';
import { useAppStore } from '@/stores/appStore';
import { computeSteadiness, getSteadinessLabel, getTrendLabel } from '@/lib/steadiness';
import { motion } from 'framer-motion';
import { Gauge, TrendingUp, TrendingDown, Minus, Clock, AlertTriangle, Zap } from 'lucide-react';

export default function SteadinessCard() {
  const { entries } = useAppStore();
  const report = useMemo(() => computeSteadiness(entries), [entries]);

  if (entries.length < 5) return null;

  const { label, emoji } = getSteadinessLabel(report.score);
  const trendLabel = getTrendLabel(report.trend);

  const TrendIcon =
    report.trend === 'improving' ? TrendingUp :
    report.trend === 'dipping' ? TrendingDown : Minus;

  const trendColor =
    report.trend === 'improving' ? 'text-primary' :
    report.trend === 'dipping' ? 'text-accent' : 'text-muted-foreground';

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="p-5 rounded-3xl bg-card border border-border/50 shadow-[var(--shadow-card)]"
    >
      {/* Header: Score + Trend */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Gauge className="w-4 h-4 text-primary" />
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Steadiness</h3>
        </div>
        <div className={`flex items-center gap-1 ${trendColor}`}>
          <TrendIcon className="w-3.5 h-3.5" />
          <span className="text-[10px] font-semibold">{trendLabel}</span>
        </div>
      </div>

      {/* Score bar */}
      <div className="flex items-center gap-3 mb-4">
        <div className="text-2xl">{emoji}</div>
        <div className="flex-1">
          <div className="flex items-baseline justify-between mb-1.5">
            <span className="text-lg font-serif font-bold text-foreground">{report.score}</span>
            <span className="text-xs text-muted-foreground font-medium">{label}</span>
          </div>
          <div className="h-2 rounded-full bg-border/50 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${report.score}%` }}
              transition={{ duration: 0.8, ease: 'easeOut', delay: 0.3 }}
              className={`h-full rounded-full ${
                report.score >= 65 ? 'bg-primary' :
                report.score >= 40 ? 'bg-primary/60' : 'bg-accent/60'
              }`}
            />
          </div>
        </div>
      </div>

      {/* Key metrics row */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        {/* Volatility */}
        <div className="p-2.5 rounded-xl bg-muted/50 text-center">
          <p className="text-lg font-serif font-bold text-foreground">{report.volatility}</p>
          <p className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wide">Volatility</p>
        </div>

        {/* Level streak */}
        <div className="p-2.5 rounded-xl bg-muted/50 text-center">
          <p className="text-lg font-serif font-bold text-foreground">{report.streakOfLevel}</p>
          <p className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wide">Level streak</p>
        </div>

        {/* Recovery time */}
        <div className="p-2.5 rounded-xl bg-muted/50 text-center">
          <p className="text-lg font-serif font-bold text-foreground">
            {report.recoveryAvgHours !== null ? (
              report.recoveryAvgHours < 1
                ? '<1h'
                : `${Math.round(report.recoveryAvgHours)}h`
            ) : '—'}
          </p>
          <p className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wide">Recovery</p>
        </div>
      </div>

      {/* Hard day warning */}
      {report.hardDayPrediction && (
        <div className="p-3 rounded-xl bg-accent/8 border border-accent/15 flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-accent shrink-0 mt-0.5" />
          <div>
            <p className="text-[11px] font-semibold text-foreground">
              {report.hardDayPrediction.day}s run hot
            </p>
            <p className="text-[10px] text-muted-foreground leading-relaxed mt-0.5">
              {report.hardDayPrediction.reason}
            </p>
          </div>
        </div>
      )}

      {/* Wiring breakdown — compact */}
      {report.regulationBreakdown.length > 0 && (
        <div className="mt-3 pt-3 border-t border-border/30">
          <div className="flex items-center gap-1.5 mb-2">
            <Zap className="w-3 h-3 text-muted-foreground" />
            <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-wider">Your wiring</span>
          </div>
          <div className="flex gap-1.5 flex-wrap">
            {report.regulationBreakdown.map(({ state, pct }) => {
              const labels: Record<string, { emoji: string; name: string }> = {
                calm: { emoji: '🌊', name: 'Level' },
                grounded: { emoji: '🪨', name: 'Solid' },
                hopeful: { emoji: '🌱', name: 'Hopeful' },
                activated: { emoji: '⚡', name: 'Wired' },
                dissociated: { emoji: '🌫️', name: 'Checked out' },
              };
              const meta = labels[state] || { emoji: '❓', name: state };
              const isGood = ['calm', 'grounded', 'hopeful'].includes(state);
              return (
                <span
                  key={state}
                  className={`text-[10px] px-2 py-1 rounded-full font-semibold ${
                    isGood
                      ? 'bg-primary/10 text-primary'
                      : 'bg-accent/10 text-accent'
                  }`}
                >
                  {meta.emoji} {meta.name} {pct}%
                </span>
              );
            })}
          </div>
        </div>
      )}
    </motion.div>
  );
}
