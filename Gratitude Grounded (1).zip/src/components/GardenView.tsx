import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { GratitudeEntry } from '@/types';
import { useAppStore, VisualMode } from '@/stores/appStore';
import { haptics } from '@/lib/haptics';

interface GardenProps {
  entries: GratitudeEntry[];
  streak: number;
  isResting: boolean;
}

// ─── Stage calculation (shared across all modes) ───
function getStage(totalEntries: number): number {
  if (totalEntries >= 50) return 5;
  if (totalEntries >= 25) return 4;
  if (totalEntries >= 12) return 3;
  if (totalEntries >= 5) return 2;
  if (totalEntries >= 1) return 1;
  return 0;
}

// ─── Mode configs ───
const MODE_CONFIG: Record<VisualMode, {
  label: string;
  icon: string;
  stages: string[];
  description: (count: number) => string;
}> = {
  roots: {
    label: 'Roots',
    icon: '🌿',
    stages: ['Planted', 'Shallow', 'Grounding', 'Deep', 'Anchored', 'Bedrock'],
    description: (n) => `${n} check-in${n !== 1 ? 's' : ''} — roots deepen with each one.`,
  },
  canopy: {
    label: 'Canopy',
    icon: '🌳',
    stages: ['Planted', 'Budding', 'Growing', 'Full', 'Flourishing', 'Thriving'],
    description: (n) => `${n} check-in${n !== 1 ? 's' : ''} — the canopy fills out as you grow.`,
  },
  compass: {
    label: 'Compass',
    icon: '🧭',
    stages: ['Set down', 'Finding north', 'Orienting', 'Calibrated', 'Locked in', 'True north'],
    description: (n) => `${n} check-in${n !== 1 ? 's' : ''} — your compass gets sharper.`,
  },
  steel: {
    label: 'Steel',
    icon: '⚙️',
    stages: ['Foundry', 'Smelted', 'Forged', 'Tempered', 'Hardened', 'Tool steel'],
    description: (n) => `${n} check-in${n !== 1 ? 's' : ''} — every rep strengthens the steel.`,
  },
};

// ─── SVG Visuals per mode ───

function RootsSVG({ stage, opacity }: { stage: number; opacity: number }) {
  const roots = [
    { x: 100, angle: -90, len: 60, w: 2.5, delay: 0 },
    { x: 80, angle: -110, len: 50, w: 1.5, delay: 0.1 },
    { x: 120, angle: -70, len: 50, w: 1.5, delay: 0.1 },
    { x: 60, angle: -120, len: 40, w: 1, delay: 0.2 },
    { x: 140, angle: -60, len: 40, w: 1, delay: 0.2 },
  ];
  const visible = Math.min(stage, roots.length);

  return (
    <svg viewBox="0 0 200 120" className="w-full h-24" style={{ opacity }}>
      <line x1="0" y1="10" x2="200" y2="10" stroke="hsl(var(--border))" strokeWidth="1" strokeDasharray="4 4" />
      <motion.line x1="100" y1="0" x2="100" y2="10" stroke="hsl(var(--primary))" strokeWidth="3" strokeLinecap="round"
        initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.5 }} />
      {roots.slice(0, visible).map((r, i) => {
        const rad = (r.angle * Math.PI) / 180;
        const x2 = r.x + Math.cos(rad) * r.len;
        const y2 = 10 - Math.sin(rad) * r.len;
        return (
          <motion.line key={i} x1={r.x} y1={10} x2={x2} y2={y2}
            stroke="hsl(var(--primary))" strokeWidth={r.w} strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }} animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: r.delay + 0.3 }} />
        );
      })}
      <StageDots stage={stage} y={115} />
    </svg>
  );
}

function CanopySVG({ stage, opacity }: { stage: number; opacity: number }) {
  const branches = [
    { x: 100, angle: 90, len: 70, w: 3, delay: 0 },
    { x: 90, angle: 130, len: 40, w: 1.5, delay: 0.1 },
    { x: 110, angle: 50, len: 40, w: 1.5, delay: 0.1 },
    { x: 76, angle: 145, len: 30, w: 1, delay: 0.2 },
    { x: 124, angle: 35, len: 30, w: 1, delay: 0.2 },
  ];
  const leaves = [
    { cx: 100, cy: 15, r: 22, delay: 0.5 },
    { cx: 70, cy: 25, r: 16, delay: 0.6 },
    { cx: 130, cy: 25, r: 16, delay: 0.6 },
    { cx: 55, cy: 40, r: 12, delay: 0.7 },
    { cx: 145, cy: 40, r: 12, delay: 0.7 },
  ];
  const visB = Math.min(stage + 1, branches.length);
  const visL = Math.min(stage, leaves.length);

  return (
    <svg viewBox="0 0 200 120" className="w-full h-28" style={{ opacity }}>
      {leaves.slice(0, visL).map((l, i) => (
        <motion.circle key={i} cx={l.cx} cy={l.cy} r={l.r}
          fill={`hsl(var(--primary) / ${0.15 + stage * 0.05})`}
          initial={{ scale: 0, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, delay: l.delay, type: 'spring', damping: 12 }} />
      ))}
      {branches.slice(0, visB).map((b, i) => {
        const rad = (b.angle * Math.PI) / 180;
        return (
          <motion.line key={i} x1={b.x} y1={110} x2={b.x + Math.cos(rad) * b.len} y2={110 - Math.sin(rad) * b.len}
            stroke="hsl(var(--primary))" strokeWidth={b.w} strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }} animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: b.delay + 0.2 }} />
        );
      })}
      <line x1="0" y1="112" x2="200" y2="112" stroke="hsl(var(--border))" strokeWidth="1" strokeDasharray="4 4" />
      <StageDots stage={stage} y={118} />
    </svg>
  );
}

function CompassSVG({ stage, opacity }: { stage: number; opacity: number }) {
  const needleLength = 20 + stage * 12;
  const wobble = Math.max(0, 15 - stage * 3); // less wobble as you calibrate

  return (
    <svg viewBox="0 0 200 120" className="w-full h-28" style={{ opacity }}>
      {/* Outer ring */}
      <circle cx="100" cy="60" r="50" fill="none" stroke="hsl(var(--border))" strokeWidth="1.5" />
      {stage >= 2 && <circle cx="100" cy="60" r="38" fill="none" stroke="hsl(var(--border) / 0.5)" strokeWidth="0.5" />}
      {/* Cardinal ticks */}
      {['N', 'E', 'S', 'W'].map((dir, i) => {
        const angle = i * 90 - 90;
        const rad = (angle * Math.PI) / 180;
        const x1 = 100 + Math.cos(rad) * 46;
        const y1 = 60 + Math.sin(rad) * 46;
        const x2 = 100 + Math.cos(rad) * 54;
        const y2 = 60 + Math.sin(rad) * 54;
        return (
          <g key={dir}>
            <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="hsl(var(--muted-foreground))" strokeWidth="1.5" />
            <text x={100 + Math.cos(rad) * 58} y={60 + Math.sin(rad) * 58 + 3}
              textAnchor="middle" fontSize="7" fill="hsl(var(--muted-foreground))" fontWeight="bold">{dir}</text>
          </g>
        );
      })}
      {/* Needle */}
      <motion.line
        x1="100" y1={60 + needleLength * 0.3}
        x2="100" y2={60 - needleLength * 0.7}
        stroke="hsl(var(--primary))" strokeWidth="2.5" strokeLinecap="round"
        initial={{ rotate: -30, opacity: 0 }}
        animate={{ rotate: wobble, opacity: 1 }}
        transition={{ duration: 1.2, type: 'spring', damping: stage >= 4 ? 20 : 8 }}
        style={{ transformOrigin: '100px 60px' }}
      />
      {/* Center dot */}
      <circle cx="100" cy="60" r="3" fill="hsl(var(--primary))" />
      {stage >= 3 && <circle cx="100" cy="60" r="5" fill="none" stroke="hsl(var(--primary) / 0.3)" strokeWidth="1" />}
      <StageDots stage={stage} y={118} />
    </svg>
  );
}

function SteelSVG({ stage, opacity }: { stage: number; opacity: number }) {
  // A beam/girder that gets more refined with each stage
  const beamWidth = 120;
  const beamHeight = 16 + stage * 2;
  const x = (200 - beamWidth) / 2;
  const y = 50;
  const segments = Math.min(stage + 1, 5);

  return (
    <svg viewBox="0 0 200 120" className="w-full h-24" style={{ opacity }}>
      {/* Main beam */}
      <motion.rect
        x={x} y={y} width={beamWidth} height={beamHeight} rx={stage >= 3 ? 2 : 0}
        fill={`hsl(var(--primary) / ${0.1 + stage * 0.04})`}
        stroke="hsl(var(--primary))" strokeWidth={stage >= 4 ? 2 : 1.5}
        initial={{ scaleX: 0 }} animate={{ scaleX: 1 }}
        transition={{ duration: 0.8 }}
        style={{ transformOrigin: `${x}px ${y + beamHeight / 2}px` }}
      />
      {/* Cross-bracing — more refined at higher stages */}
      {Array.from({ length: segments }).map((_, i) => {
        const sx = x + (beamWidth / (segments + 1)) * (i + 1);
        return (
          <motion.line key={i}
            x1={sx} y1={y} x2={sx} y2={y + beamHeight}
            stroke="hsl(var(--primary) / 0.5)" strokeWidth="1"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
            transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }} />
        );
      })}
      {/* Rivets at stage 3+ */}
      {stage >= 3 && Array.from({ length: segments }).map((_, i) => {
        const sx = x + (beamWidth / (segments + 1)) * (i + 1);
        return (
          <g key={`rivet-${i}`}>
            <motion.circle cx={sx} cy={y + 3} r="1.5" fill="hsl(var(--primary))"
              initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.8 + i * 0.05 }} />
            <motion.circle cx={sx} cy={y + beamHeight - 3} r="1.5" fill="hsl(var(--primary))"
              initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.85 + i * 0.05 }} />
          </g>
        );
      })}
      {/* Temper glow at stage 4+ */}
      {stage >= 4 && (
        <motion.rect
          x={x + 2} y={y + 2} width={beamWidth - 4} height={beamHeight - 4} rx={1}
          fill="none" stroke="hsl(var(--primary) / 0.2)" strokeWidth="1"
          initial={{ opacity: 0 }} animate={{ opacity: [0, 0.6, 0.3] }}
          transition={{ duration: 2, repeat: Infinity, repeatType: 'reverse' }}
        />
      )}
      <StageDots stage={stage} y={100} />
    </svg>
  );
}

function StageDots({ stage, y }: { stage: number; y: number }) {
  return (
    <g>
      {[0, 1, 2, 3, 4].map(level => (
        <circle key={level} cx={80 + level * 10} cy={y} r={2}
          fill={level < stage ? 'hsl(var(--primary))' : 'hsl(var(--border))'} />
      ))}
    </g>
  );
}

// ─── Mode Selector ───
function ModeSelector({ current, onChange }: { current: VisualMode; onChange: (m: VisualMode) => void }) {
  const modes: VisualMode[] = ['roots', 'canopy', 'compass', 'steel'];
  return (
    <div className="flex gap-1.5">
      {modes.map(m => (
        <button
          key={m}
          onClick={() => { haptics.light(); onChange(m); }}
          className={`text-[10px] px-2.5 py-1 rounded-full font-semibold transition-all duration-200 ${
            current === m
              ? 'bg-primary/15 text-primary border border-primary/30'
              : 'text-muted-foreground hover:text-foreground border border-transparent'
          }`}
        >
          {MODE_CONFIG[m].icon} {MODE_CONFIG[m].label}
        </button>
      ))}
    </div>
  );
}

// ─── Main Component ───
export default function GardenView({ entries, streak, isResting }: GardenProps) {
  const visualMode = useAppStore(s => s.visualMode);
  const setVisualMode = useAppStore(s => s.setVisualMode);

  const stage = useMemo(() => getStage(entries.length), [entries.length]);
  const config = MODE_CONFIG[visualMode];
  const stageLabel = config.stages[Math.min(stage, config.stages.length - 1)];
  const opacity = isResting ? 0.85 : 1;

  const Visual = {
    roots: RootsSVG,
    canopy: CanopySVG,
    compass: CompassSVG,
    steel: SteelSVG,
  }[visualMode];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-5 rounded-3xl bg-gradient-to-br from-primary/8 via-card to-card border border-primary/10 shadow-[var(--shadow-card)]"
    >
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-bold text-primary uppercase tracking-wider">
          Your Progress
        </p>
        <div className="flex items-center gap-2">
          {isResting && (
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-accent/10 text-accent font-semibold">
              paused
            </span>
          )}
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">
            {stageLabel}
          </span>
        </div>
      </div>

      <p className="text-[10px] text-muted-foreground mb-3">
        {config.description(entries.length)}
      </p>

      <Visual stage={stage} opacity={opacity} />

      {/* Mode selector */}
      <div className="mt-3 pt-3 border-t border-border/30 flex items-center justify-between">
        <span className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider">Style</span>
        <ModeSelector current={visualMode} onChange={setVisualMode} />
      </div>
    </motion.div>
  );
}
