export interface GratitudeItem {
  id: string;
  text: string;
  category?: string;
  emotion?: string;
  bodyLocation?: string;
  belief?: string;
}

export type RegulationState = 'calm' | 'activated' | 'dissociated' | 'hopeful' | 'grounded';

export interface GratitudeEntry {
  id: string;
  createdAt: string;
  entryDatetime: string;
  mood: number;
  stress: number;
  note?: string;
  regulationState?: RegulationState;
  items: GratitudeItem[];
}

export interface GroundingSession {
  id: string;
  sessionDatetime: string;
  type: 'breathing' | '54321' | 'combined';
  durationSec: number;
  preMood: number;
  postMood: number;
}

export type TemplateKey =
  | '3-good-things'
  | 'senses-54321'
  | 'reframe'
  | 'micro-wins'
  | 'people-support'
  | 'values'
  | 'acts-of-kindness'
  | 'body-gratitude'
  | 'nature'
  | 'tomorrow';

export interface Template {
  key: TemplateKey;
  name: string;
  description: string;
  icon: string;
  promptCount: number;
}
